﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace BaliEnterpriseSystems
{
    public partial class Best : System.Web.UI.MasterPage
    {
        protected void Page_Init(object sender, EventArgs e)
        {

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["CurrentUser"] == null)
            {
                Response.Redirect("Logout.aspx");
            }
            else if ((!Utils.User.BestUser.IsLoggedIn) && Utils.User.BestUser.initialPassword)
            {
                Response.Redirect("InitialPasswordChage.aspx");
            }
            else if (!Utils.User.BestUser.IsLoggedIn)
            {
                Response.Redirect("NotLoggedIn.aspx");
            }

            ltrUserName.Text = Utils.User.BestUser.userName;
            ltrMainMenu.Text = UtilMenu.MainMenu();

        }
    }
}

﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace BaliEnterpriseSystems
{
    public class UtilMenu
    {
        public static string MainMenu()
        {
            string result = "<table cellpadding=\"0\" cellspacing=\"0\"><tr>";
            result += "<td id=\"tdMenu1\"><a href=\"Dashboard.aspx?ms=1\">Dashboard</a></td>";
            if (Utils.User.UserRoleByName("1.Programs").allowView)
                result += "<td id=\"tdMenu2\"><a href=\"ProgramsInfo.aspx?ms=2\">Programs</a></td>";

            if (Utils.User.UserRoleByName("2.Students").allowView)
                result += "<td id=\"tdMenu3\"><a href=\"StudentsInfo.aspx?ms=3\">Students</a></td>";

            if (Utils.User.UserRoleByName("3.Tutors").allowView)
                result += "<td id=\"tdMenu4\"><a href=\"TutorsInfo.aspx?ms=4\">Tutors</a></td>";

            if (Utils.User.UserRoleByName("5.Schedules").allowView)
                result += "<td id=\"tdMenu5\"><a href=\"SchedulesInfo.aspx?ms=5\">Schedules</a></td>";

            if (Utils.User.UserRoleByName("4.Payments").allowView)
                result += "<td id=\"tdMenu6\"><a href=\"BestPaymentTypes.aspx?ms=6\">Payments</a></td>";

            if (Utils.User.UserRoleByName("6.Setup").allowView)
                result += "<td id=\"tdMenu7\"><a href=\"BestServicesInfo.aspx?ms=7\">Setup</a></td>";

            result += "</tr></table>";

            return result;
        }

        public static string SetupSubMenu(string curmenu)
        {
            string result = "<ul class=\"submenu\">";

            if (Utils.User.UserRoleByName("Setup - Services").allowView)
                if(curmenu.Equals("services"))
                    result += "<li style=\"background-color:#e0c240\">Services</li>";
                else
                    result += "<li><a href=\"BestServicesInfo.aspx?ms=7\">Services</a></li>";

            if (Utils.User.UserRoleByName("Setup - Center Information").allowView)
                if(curmenu.Equals("centers"))
                    result += "<li style=\"background-color:#e0c240\">Center Information</li>";
                else
                    result += "<li><a href=\"BestCenterInfo.aspx?ms=7\">Center Information</a></li>";

            if (Utils.User.UserRoleByName("Setup - Users").allowView)
                if(curmenu.Equals("userinfo"))
                    result += "<li style=\"background-color:#e0c240\">Users</li>";
                else
                    result += "<li><a href=\"UserInfo.aspx?ms=7\">Users</a></li>";

            if (Utils.User.UserRoleByName("Setup - User Roles").allowView)
                if(curmenu.Equals("userroles"))
                    result += "<li style=\"background-color:#e0c240\">User Roles</li>";
                else
                    result += "<li><a href=\"UserRolesInfo.aspx?ms=7\">User Roles</a></li>";

            if (Utils.User.UserRoleByName("Setup - EMail Template").allowView)
                if(curmenu.Equals("emailtemplate"))
                    result += "<li style=\"background-color:#e0c240\">EMail Templates</li>";
                else
                    result += "<li><a href=\"EMailTemplates.aspx?ms=7\">EMail Templates</a></li>";

            result += "</ul>";

            return result;
        }

        public static string ProgramMenu(string curmenu)
        {
            string result = "<ul class=\"submenu\">";

            if (Utils.User.UserRoleByName("Program - Types").allowView)
                if(curmenu.Equals("programtypes"))
                    result += "<li style=\"background-color:#e67399\">Program Types</li>";
                else
                    result += "<li><a href=\"ProgramsInfo.aspx?ms=2\">Program Types</a></li>";

            if (Utils.User.UserRoleByName("Program - Information").allowView)
                if(curmenu.Equals("programinfo"))
                    result += "<li style=\"background-color:#e67399\">Programs</li>";
                else
                    result += "<li><a href=\"ProgramNames.aspx?ms=2\">Programs</a></li>";

            result += "</ul>";

            return result;
        }

        public static string StudentMenu(string curmenu)
        {
            string result = "<ul class=\"submenu\">";

            if (Utils.User.UserRoleByName("Student - Information").allowView)
                if(curmenu.Equals("studentinfo"))
                    result += "<li style=\"background-color:#A5A5D1\">Student Info</li>";
                else
                    result += "<li><a href=\"StudentsInfo.aspx?ms=3\">Student Info</a></li>";

            if (Utils.User.UserRoleByName("Student - Notes").allowView)
                if(curmenu.Equals("studentnotes"))
                    result += "<li style=\"background-color:#A5A5D1\">Student Notes</li>";
                else
                    result += "<li><a href=\"StudentNotes.aspx?ms=3\">Student Notes</a></li>";

            if (Utils.User.UserRoleByName("Student - Reports").allowView)
                if(curmenu.Equals("studentreports"))
                    result += "<li style=\"background-color:#A5A5D1\">Student Reports</li>";
                else
                    result += "<li><a href=\"StudentReports.aspx?ms=3\">Student Reports</a></li>";

            if (Utils.User.UserRoleByName("Student - Pictures").allowView)
                if (curmenu.Equals("studentpicture"))
                    result += "<li style=\"background-color:#A5A5D1\">Student Pictures</li>";
                else
                    result += "<li><a href=\"BestStudentPictures.aspx?ms=3\">Student Picture</a></li>";

            if (Utils.User.UserRoleByName("Student - Users").allowView)
                if (curmenu.Equals("studentusers"))
                    result += "<li style=\"background-color:#A5A5D1\">Student Users</li>";
                else
                    result += "<li><a href=\"BestStudentUser.aspx?ms=3\">Student Users</a></li>";

            if (Utils.User.UserRoleByName("Payment - Details").allowView)
                result += "<li><a href=\"PaymentsInfo.aspx?ms=6\">Payment Details</a></li>";

            result += "</ul>";

            return result;
        }

        public static string TutorMenu(string curmenu)
        {
            string result = "<ul class=\"submenu\">";

            if (Utils.User.UserRoleByName("Tutor - Information").allowView)
                if(curmenu.Equals("tutorinfo"))
                    result += "<li style=\"background-color:#DBDCBA\">Tutors Info</li>";
                else
                    result += "<li><a href=\"TutorsInfo.aspx?ms=4\">Tutors Info</a></li>";

            if (Utils.User.UserRoleByName("Tutor - Reports").allowView)
                if(curmenu.Equals("tutorreports"))
                    result += "<li style=\"background-color:#DBDCBA\">Tutor Reports</li>";
                else
                    result += "<li><a href=\"TutorReports.aspx?ms=4\">Tutor Reports</a></li>";

            result += "</ul>";

            return result;
        }

        public static string PaymentMenu(string curmenu)
        {
            string result = "<ul class=\"submenu\">";

            if (Utils.User.UserRoleByName("Payment - Types").allowView)
                if(curmenu.Equals("paymenttypes"))
                    result += "<li style=\"background-color:#59bfb3\">Payment Types</li>";
                else
                    result += "<li><a href=\"BestPaymentTypes.aspx?ms=6\">Payment Types</a></li>";

            if (Utils.User.UserRoleByName("Payment - Details").allowView)
                if(curmenu.Equals("paymentdetails"))
                    result += "<li style=\"background-color:#59bfb3\">Payment Details</li>";
                else
                    result += "<li><a href=\"PaymentsInfo.aspx?ms=6\">Payment Details</a></li>";

            if (Utils.User.UserRoleByName("Payment - Reports").allowView)
                if(curmenu.Equals("paymentreports"))
                    result += "<li style=\"background-color:#59bfb3\">Payment Reports</li>";
                else
                    result += "<li><a href=\"PaymentReports.aspx?ms=6\">Payment Reports</a></li>";

            result += "</ul>";

            return result;
        }
    }
}

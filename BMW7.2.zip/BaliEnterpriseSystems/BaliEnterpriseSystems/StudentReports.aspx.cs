﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using BaliEnterpriseSystems.BestObjects;
using System.Text;
using System.Data.OleDb;

namespace BaliEnterpriseSystems
{
    public partial class StudentReports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["CurrentUser"] == null)
            {
                Response.Redirect("Logout.aspx");
            }
            ltrSubMenu.Text = UtilMenu.StudentMenu("studentreports");
            if (!Utils.User.UserRoleByName("Student - Reports").allowView)
            {
                ltrGrid.Text = "You do not have rights to view.";
                return;
            }            

            string ms = Request.QueryString["ms"];
            ltrMScript.Text = Utils.MenuSelectScript(ms);
            StringBuilder rowshtml = new StringBuilder();
            string fromdate = Request.Form["fromdate"];
            string todate = Request.Form["todate"];
            string summaryby = Request.Form["summaryby"];
            if (string.IsNullOrEmpty(summaryby)) summaryby = "";

            if (IsPostBack)
            {
                bool canReport = true;
                if (!string.IsNullOrEmpty(fromdate))
                {
                    try
                    {
                        DateTime fromdt = Convert.ToDateTime(fromdate);
                    }
                    catch (Exception ex)
                    {
                        ltrValidateMsg.Text = Utils.WarningMessage(ex.Message);
                        canReport = false;
                    }
                }
                else
                {
                    ltrValidateMsg.Text = Utils.WarningMessage("From Date is Required.");
                    canReport = false;
                }

                if (!string.IsNullOrEmpty(todate))
                {
                    try
                    {
                        DateTime todt = Convert.ToDateTime(todate);
                    }
                    catch (Exception ex)
                    {
                        ltrValidateMsg.Text = Utils.WarningMessage(ex.Message);
                        canReport = false;
                    }
                }
                else
                {
                    ltrValidateMsg.Text = Utils.WarningMessage("To Date is Required.");
                    canReport = false;
                }

                if (canReport)
                {
                    BestField bffromdate = new BestField() { fieldName = "fromdate", fieldSize = 40, fieldType = "System.String", paramOledbType = System.Data.OleDb.OleDbType.VarChar, displayField = false };
                    fromdate = fromdate.Substring(6, 4) + fromdate.Substring(0, 2) + fromdate.Substring(3, 2);

                    bffromdate.fieldValue = fromdate;

                    BestField bftodate = new BestField() { fieldName = "todate", fieldSize = 40, fieldType = "System.String", paramOledbType = System.Data.OleDb.OleDbType.VarChar, displayField = false };
                    todate = todate.Substring(6, 4) + todate.Substring(0, 2) + todate.Substring(3, 2);
                    bftodate.fieldValue = todate;

                    string tsql = "select schdate,studentid,firstName,lastName, case when trantype='Scheduled' then amount else 0 end as tobecharged, case when trantype!='Scheduled' then amount else 0 end as paid, trantype from VBestSchedulesAndPayments inner join BestStudents on beststudents.guidfield = VBestSchedulesAndPayments.studentguid where schdate >= ? and schdate <= ? order by schdate";

                    BestDatabase db = new BestDatabase();
                    OleDbCommand myCmd = db.dbCmd;
                    myCmd.CommandText = tsql;
                    myCmd.Parameters.Add(bffromdate.Param);
                    myCmd.Parameters.Add(bftodate.Param);
                    OleDbDataReader tblReader = myCmd.ExecuteReader();
                    double total = 0;
                    double chargedTotal = 0;
                    rowshtml.Append("<br /><table class=\"tblreports\" cellspacing=\"0\" cellpadding=\"0\">");
                    rowshtml.Append("<tr><th style=\"text-align:center;\">Date</th>");
                    rowshtml.Append("<th style=\"text-align:center;\">Student Id</th>");
                    rowshtml.Append("<th style=\"text-align:center;\">First Name</th>");
                    rowshtml.Append("<th style=\"text-align:center;\">Last Name</th>");
                    rowshtml.Append("<th style=\"text-align:center;\">Amount Charged</th>");
                    rowshtml.Append("<th style=\"text-align:center;\">Amount Paid</th>");
                    rowshtml.Append("<th style=\"text-align:center;\">Trans Type</th></tr>");
                    while (tblReader.Read())
                    {
                        string paydate = tblReader[0].ToString();
                        string stuid = tblReader[1].ToString();
                        string firstname = tblReader[2].ToString();
                        string lastname = tblReader[3].ToString();
                        double payAmt = Convert.ToDouble(tblReader[5].ToString());
                        double tobecharged = Convert.ToDouble(tblReader[4].ToString());
                        total += payAmt;
                        chargedTotal += tobecharged;
                        rowshtml.Append("<tr><td>" + paydate + "</td>");
                        rowshtml.Append("<td>" + HttpUtility.HtmlEncode(tblReader[1].ToString()) + "</td>");
                        rowshtml.Append("<td>" + HttpUtility.HtmlEncode(tblReader[2].ToString()) + "</td>");
                        rowshtml.Append("<td>" + HttpUtility.HtmlEncode(tblReader[3].ToString()) + "</td>");
                        rowshtml.Append("<td class=\"ra\" style=\"padding-right:3px;\">" + tobecharged.ToString("0.00") + "</td>");
                        rowshtml.Append("<td class=\"ra\" style=\"padding-right:3px;\">" + payAmt.ToString("0.00") + "</td>");
                        rowshtml.Append("<td>" + HttpUtility.HtmlEncode(tblReader[6].ToString()) + "</td></tr>");
                    }
                    rowshtml.Append("<tr><th colspan=\"4\">Total</th>");
                    rowshtml.Append("<th class=\"ra\" style=\"padding-right:3px;\">" + chargedTotal.ToString("0.00") + "</th>");
                    rowshtml.Append("<th class=\"ra\" style=\"padding-right:3px;\">" + total.ToString("0.00") + "</th><th>&nbsp;</th></tr>");
                    rowshtml.Append("<tr><th colspan=\"6\" class=\"ra\" style=\"padding-right:3px;\">Balance Amount : " + (total - chargedTotal).ToString("0.00") + "</th></tr>");
                    rowshtml.Append("</table><br />");

                }
            }

            StringBuilder sb = new StringBuilder();
            sb.Append("<div class=\"centered\">");
            sb.Append("<table class=\"bestgrid\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">");
            sb.Append("<tr><td style=\"text-align:center;\" colspan=\"4\">Student Reports</td></tr>");
            sb.Append("<tr><td>From Date <input type=\"text\" id=\"fromdate\" name=\"fromdate\" size=\"9\" maxlength=\"10\" value=\"" + fromdate + "\" /></td><td>To Date <input type=\"text\" id=\"todate\" name=\"todate\" size=\"9\" maxlength=\"10\" value=\"" + todate + "\" /></td></tr>");
            sb.Append("<tr><td>Summary By <select id=\"summaryby\" name=\"summaryby\"><option value=\"\"></option>");
            sb.Append("<option value=\"paydate\" " + (summaryby.Equals("paydate") ? " selected " : "") + ">Payment Date</option>");
            sb.Append("<option value=\"payweek\" " + (summaryby.Equals("payweek") ? " selected " : "") + ">Week</option>");
            sb.Append("<option value=\"paymonth\" " + (summaryby.Equals("paymonth") ? " selected " : "") + ">Month</option>");
            sb.Append("<option value=\"payyear\" " + (summaryby.Equals("payyear") ? " selected " : "") + ">Year</option>");
            sb.Append("</select></td>");
            sb.Append("<td>&nbsp;</td></tr>");
            sb.Append("<tr><td colspan=\"2\"><input type=\"button\" value=\"Report\" onclick=\"submit();\" /></td></tr>");
            sb.Append("</table>");
            ltrGrid.Text = sb.ToString() + rowshtml.ToString() + "</div>";

        }
    }
}

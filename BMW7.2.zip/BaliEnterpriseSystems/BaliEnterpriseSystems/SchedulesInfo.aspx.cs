﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Text;
using BaliEnterpriseSystems.BestObjects;
using System.Collections.Generic;

namespace BaliEnterpriseSystems
{
    public partial class SchedulesInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["CurrentUser"] == null)
            {
                Response.Redirect("Logout.aspx");
            }

            string ms = Request.QueryString["ms"];
            ltrMScript.Text = Utils.MenuSelectScript(ms);
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            if (!Utils.User.UserRoleByName("5.Schedules").allowView)
            {
                ltrMsg.Text = "You do not have rights to view.";
                return;
            }            

            string selPlan = Request.Form["planRadio"];
            string thtml = "<input type=\"radio\" id=\"radio1\" name=\"planRadio\" onclick=\"submit();\" value=\"day\"" + ((string.IsNullOrEmpty(selPlan) || selPlan.Equals("day")) ? " checked=\"checked\"" : "") + " /><label for=\"radio1\">Day</label>";
            thtml += "<input type=\"radio\" id=\"radio2\" name=\"planRadio\" onclick=\"submit();\" value=\"week\"" + ((!string.IsNullOrEmpty(selPlan) && selPlan.Equals("week")) ? " checked=\"checked\"" : "") + "/><label for=\"radio2\">Week</label>";
            thtml += "<input type=\"radio\" id=\"radio3\" name=\"planRadio\" onclick=\"submit();\" value=\"month\"" + ((!string.IsNullOrEmpty(selPlan) && selPlan.Equals("month")) ? " checked=\"checked\"" : "") + " /><label for=\"radio3\">Month</label>";
            radioHtml.Text = thtml;

            string selHrs = Request.Form["rdoHours"];
            if (string.IsNullOrEmpty(selHrs)) selHrs = "0";
            string timechangeclick = Request.Form["hdTimeChangeClicked"];
            if (!string.IsNullOrEmpty(timechangeclick) && timechangeclick.Equals("1"))
            {
                selHrs = (selHrs.Equals("1"))?"0":"1";
            }
            ltrTimeHrs.Text = "<input type=\"hidden\" id=\"hdTimeChangeClicked\" name=\"hdTimeChangeClicked\" /><input type=\"radio\" id=\"rdoHrs\" name=\"rdoHours\" onclick=\"timeChangeSubmit();\" value=\"" + selHrs + "\" checked=\"checked\" /><label for=\"rdoHrs\">" + (selHrs.Equals("0")?"00:30":"00:00") + "</label>";

            string show6to2Clicked = Request.Form["hdshow6to2"];
            string show6to2 = Request.Form["radioshow6to2"];
            if (string.IsNullOrEmpty(show6to2)) show6to2 = "1";
            if (!string.IsNullOrEmpty(show6to2Clicked) && show6to2Clicked.Equals("1"))
            {
                show6to2 = (show6to2.Equals("0")) ? "1" : "0";
            }

            ltrshow6To2.Text = "<input type=\"hidden\" id=\"hdshow6to2\" name=\"hdshow6to2\" /><input type=\"radio\" id=\"rdoshow6to2\" name=\"radioshow6to2\" onclick=\"Show6To9Submit('hdshow6to2');\" value=\"" + show6to2 + "\"" + ((show6to2.Equals("1")) ? " checked=\"checked\"" : "") + " /><label for=\"rdoshow6to2\">6AM-2PM</label>";

            string show2to9Clicked = Request.Form["hdshow2to9"];
            string show2to9 = Request.Form["radioshow2to9"];
            if (string.IsNullOrEmpty(show2to9)) show2to9 = "1";
            if (!string.IsNullOrEmpty(show2to9Clicked) && show2to9Clicked.Equals("1"))
            {
                show2to9 = (show2to9.Equals("0")) ? "1" : "0";
            }

            ltrshow2To9.Text = "<input type=\"hidden\" id=\"hdshow2to9\" name=\"hdshow2to9\" /><input type=\"radio\" id=\"rdoshow2to9\" name=\"radioshow2to9\" onclick=\"Show6To9Submit('hdshow2to9');\" value=\"" + show2to9 + "\"" + ((show2to9.Equals("1")) ? " checked=\"checked\"" : "") + " /><label for=\"rdoshow2to9\">2PM-9PM</label>";

            string timemodeStr = "BestPlanner.plannerTimeMode = ";
            StringBuilder sbTimeSlice = new StringBuilder();
            sbTimeSlice.AppendLine("<script type=\"text/javascript\">");
            sbTimeSlice.Append("aryTimes = [");

            if(selHrs.Equals("0"))
            {
                if(show6to2.Equals("1"))
                {
                  sbTimeSlice.Append("'630', '730', '830', '930', '1030', '1130', '1230', '1330'");
                }
                if(show2to9.Equals("1"))
                {
                    if (show6to2.Equals("1")) sbTimeSlice.Append(",");
                    sbTimeSlice.Append("'1430', '1530', '1630', '1730', '1830', '1930', '2030', '2130'");
                }
                timemodeStr += "timeModeHours;";
            }
            else
            {                
                if(show6to2.Equals("1"))
                {
                  sbTimeSlice.Append(" '600', '630', '700', '730', '800', '830', '900', '930', '1000', '1030', '1100', '1130', '1200', '1230', '1300', '1330', '1400' ");
                }
                if(show2to9.Equals("1"))
                {
                    if (show6to2.Equals("1"))
                        sbTimeSlice.Append(",");
                    else
                        sbTimeSlice.Append("'1400', ");

                    sbTimeSlice.Append("'1430', '1500', '1530', '1600', '1630', '1700', '1730', '1800', '1830', '1900', '1930', '2000', '2030', '2100', '2130', '2200'");
                }
                timemodeStr += "timeModeHalfHours;";
            }
            sbTimeSlice.AppendLine("]; </script>");
            ltrTimeSlices.Text = sbTimeSlice.ToString();

            string plannerdateNav = Request.Form["plannerDateNav"];
            string curPlannerDate = Request.Form["curPlannerDate"];
            string plannerdate;
            DateTime fromDate, toDate;
           // Array days = Enum.GetValues(GetType(DayOfWeek));

            fromDate = DateTime.Today;
            toDate = fromDate;
            if (string.IsNullOrEmpty(plannerdateNav))
                plannerdateNav = "0";

            if (string.IsNullOrEmpty(curPlannerDate))
                curPlannerDate = DateTime.Today.ToString("MM/dd/yyyy");

            int direction;
            int.TryParse(plannerdateNav, out direction);
            DateTime today = Convert.ToDateTime(curPlannerDate);
            if (string.IsNullOrEmpty(selPlan) || selPlan.Equals("day"))
            {
                today = today.AddDays(direction);
                fromDate = today;
                toDate = fromDate;
            }
            else if (selPlan.Equals("week"))
            {
                today = today.AddDays(direction * 7);

                int curweek = getDay(today.DayOfWeek) * -1;
                fromDate = today.AddDays(curweek);
                toDate = fromDate.AddDays(7);
            }
            else if (selPlan.Equals("month"))
            {
                today = today.AddMonths(direction);
            }
            plannerdate = today.ToString("MM/dd/yyyy");

            
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<script type=\"text/javascript\">");
            string scheduleSample = "{\"schGuid\":\"[paramSchGuid]\",\"stuGuid1\":\"[paramStuGuid1]\",\"stuGuid2\":\"[paramStuGuid2]\",\"stuGuid3\":\"[paramStuGuid3]\",\"stuGuid4\":\"[paramStuGuid4]\",\"stuGuid5\":\"[paramStuGuid5]\",\"tutGuid\":\"[paramTutGuid]\",\"schDate\":\"[paramSchDate]\",\"schFrom\":\"[paramSchFrom]\",\"schTo\":\"[paramSchTo]\", \"isDeleted\":\"[paramIsDel]\", \"Index\":\"[paramIndex]\", \"schId\":[paramSchId] }";
            BestSchedules bsch = new BestSchedules();
            List<BestField> paramSch = new List<BestField>();
            paramSch.Add(new BestField { fieldName = "fromDate", fieldType = "System.String", paramOledbType = System.Data.OleDb.OleDbType.VarChar, fieldValue = fromDate.ToString("yyyyMMdd") });
            paramSch.Add(new BestField { fieldName = "toDate", fieldType = "System.String", paramOledbType = System.Data.OleDb.OleDbType.VarChar, fieldValue = toDate.ToString("yyyyMMdd") });

            bsch.LoadRows("schdate>=? and schdate<=?", paramSch, "schdate,schfrom");
            /* Schedules into JavaScript */
            sb.AppendLine("ScheduleInfo = [");
            int idx = 0;
            string curdate = "";
            for(int i=0;i<bsch.TableRows.Count;i++)
            {
                var datetimeSlice = bsch.TableRows[i].Fields["schDate"].fieldValue + bsch.TableRows[i].Fields["schFrom"].fieldValue;
                if (!curdate.Equals(datetimeSlice))
                {
                    curdate = datetimeSlice;
                    idx = 0;
                }
                else
                {
                    idx++;
                }
                sb.Append(ReplaceSchedule(bsch.TableRows[i], scheduleSample, idx, i));
                if(i<bsch.TableRows.Count-1) sb.AppendLine(",");
            }
            sb.AppendLine("];");

            /* Auto Student */
            string autoSample = "{value:\"[paramValue]\", label:[paramLabel]}";
            sb.AppendLine("autoStudents = [");
            BestStudents bstd = new BestStudents();
            bstd.LoadRows();
            for(int s=0;s<bstd.TableRows.Count;s++)
            {
                string result = autoSample;                
                result = result.Replace("[paramValue]", bstd.TableRows[s].Fields["guidfield"].fieldValue);                
                result = result.Replace("[paramLabel]", Utils.EnquoteJS((bstd.TableRows[s].Fields["firstName"].fieldValue??"") + " " +
                    (bstd.TableRows[s].Fields["lastName"].fieldValue??"")));
                sb.Append(result);
                if(s<bstd.TableRows.Count-1) sb.AppendLine(",");
            }
            sb.AppendLine("];");

            BestTutors bstut = new BestTutors();
            bstut.LoadRows();
            sb.AppendLine("autoTutors = [");
            for(int s=0;s<bstut.TableRows.Count;s++)
            {
                string result = autoSample;                
                result = result.Replace("[paramValue]", bstut.TableRows[s].Fields["guidfield"].fieldValue);                
                result = result.Replace("[paramLabel]", Utils.EnquoteJS((bstut.TableRows[s].Fields["firstName"].fieldValue??"") + " " +(bstut.TableRows[s].Fields["lastName"].fieldValue??"")));
                sb.Append(result);
                if(s<bstut.TableRows.Count-1) sb.AppendLine(",");
            }
            sb.AppendLine("];");

            string studentSample = "{\"firstName\":[paramFirst], \"lastName\":[paramLast], \"guid\":\"[paramGuid]\"}";
            sb.AppendLine("StudentInfo = [");
            for(int s=0;s<bstd.TableRows.Count;s++)
            {
                string result = studentSample;                
                result = result.Replace("[paramGuid]", bstd.TableRows[s].Fields["guidfield"].fieldValue);                
                result = result.Replace("[paramFirst]", Utils.EnquoteJS(bstd.TableRows[s].Fields["firstName"].fieldValue??""));
                result = result.Replace("[paramLast]", Utils.EnquoteJS(bstd.TableRows[s].Fields["lastName"].fieldValue??""));
                sb.Append(result);
                if(s<bstd.TableRows.Count-1) sb.AppendLine(",");
            }
            
            sb.AppendLine("];");
            string tutorSample = "{\"Name\":[paramName], \"guid\":\"[paramGuid]\"}";
            sb.AppendLine("TutorInfo = [");
            for (int s = 0; s < bstut.TableRows.Count; s++)
            {
                string result = tutorSample;
                result = result.Replace("[paramGuid]", bstut.TableRows[s].Fields["guidfield"].fieldValue);
                result = result.Replace("[paramName]", Utils.EnquoteJS((bstut.TableRows[s].Fields["firstName"].fieldValue ?? "") + " " +(bstut.TableRows[s].Fields["lastName"].fieldValue ?? "")));
                sb.Append(result);
                if (s < bstut.TableRows.Count - 1) sb.AppendLine(",");
            }
            sb.AppendLine("];");

            sb.AppendLine("$(document).ready(function(){");
            sb.AppendLine("BestPlanner.plannerDate = new Date('" + plannerdate  + "');");
            if (string.IsNullOrEmpty(selPlan) || selPlan.Equals("day"))
                sb.AppendLine("BestPlanner.plannerMode = PlannerDay;");
            else if (selPlan.Equals("week"))
                sb.AppendLine("BestPlanner.plannerMode = PlannerWeek;");
            else if (selPlan.Equals("month"))
                sb.AppendLine("BestPlanner.plannerMode = PlannerMonth;");
            sb.AppendLine(timemodeStr);
            sb.AppendLine("BestPlanner.Show();");
            sb.AppendLine("BestPlanner.extendToSchedule();");
            sb.AppendLine("setTimeout(\"BestPlanner.DrawSchedules();\", 200);");
            sb.AppendLine("});");
            sb.AppendLine("</script>");
            ltrScript.Text = sb.ToString();
        }

        private string ReplaceSchedule(BestRow bs, string sample, int idx, int schId)
        {
            string result = sample;
            result = result.Replace("[paramSchGuid]", bs.Fields["guidfield"].fieldValue);
            result = result.Replace("[paramStuGuid1]", bs.Fields["stuGuid1"].fieldValue??"");
            result = result.Replace("[paramStuGuid2]", bs.Fields["stuGuid2"].fieldValue??"");
            result = result.Replace("[paramStuGuid3]", bs.Fields["stuGuid3"].fieldValue??"");
            result = result.Replace("[paramStuGuid4]", bs.Fields["stuGuid4"].fieldValue??"");
            result = result.Replace("[paramStuGuid5]", bs.Fields["stuGuid5"].fieldValue??"");
            result = result.Replace("[paramTutGuid]", bs.Fields["tutGuid"].fieldValue??"");
            result = result.Replace("[paramSchDate]", bs.Fields["schDate"].fieldValue ?? "");
            result = result.Replace("[paramSchFrom]", bs.Fields["schFrom"].fieldValue ?? "");
            result = result.Replace("[paramSchTo]", bs.Fields["schTo"].fieldValue ?? "");
            result = result.Replace("[paramIndex]", idx.ToString());
            if((bs.Fields["isDeleted"].fieldValue ?? "").Equals("False"))
                result = result.Replace("[paramIsDel]", "0");
            else
                result = result.Replace("[paramIsDel]", "1");
            result = result.Replace("[paramSchId]", schId.ToString());

            return result;
        }

        private int getDay(DayOfWeek dw)
        {
            int result = 1;
            if (dw == DayOfWeek.Sunday)
                result = 1;
            else if (dw == DayOfWeek.Monday)
                result = 2;
            else if (dw == DayOfWeek.Tuesday)
                result = 3;
            else if (dw == DayOfWeek.Wednesday)
                result = 4;
            else if (dw == DayOfWeek.Thursday)
                result = 5;
            else if (dw == DayOfWeek.Friday)
                result = 6;
            else if (dw == DayOfWeek.Saturday)
                result = 7;

            return result;
        }
    }
}

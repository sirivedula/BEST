﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using BaliEnterpriseSystems.BestObjects;
using System.Collections.Generic;

namespace BaliEnterpriseSystems
{
    public partial class SaveSchedule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["CurrentUser"] == null)
            {
                Response.Redirect("Logout.aspx");
            }

            string tutGuid = Request.Form["tutGuid"];
            string stuGuid1 = Request.Form["stuGuid1"];
            string stuGuid2 = Request.Form["stuGuid2"];
            string stuGuid3 = Request.Form["stuGuid3"];
            string stuGuid4 = Request.Form["stuGuid4"];
            string stuGuid5 = Request.Form["stuGuid5"];
            string schGuid = Request.Form["schGuid"];
            string schDate = Request.Form["schDate"];
            string schFrom = Request.Form["schFrom"];
            string schTo = Request.Form["schTo"];
            string isdelete = Request.Form["isDel"];
            string attend1 = Request.Form["attend1"];
            string attend2 = Request.Form["attend2"];
            string attend3 = Request.Form["attend3"];
            string attend4 = Request.Form["attend4"];
            string attend5 = Request.Form["attend5"];

            BestSchedules bsch = new BestSchedules();
            if (Utils.IsGuid(schGuid))
            {
                /* Update */
                if (!(Utils.User.UserRoleByName("5.Schedules").allowEdit))
                {
                    Response.Write("{result:false,Message:'You do not have rights to edit.'}");
                    return;
                }

                List<BestField> bparams = new List<BestField>();
                BestField guid = new BestField() { fieldName = "guidfield", fieldSize = 40, fieldType = "System.Guid", paramOledbType = System.Data.OleDb.OleDbType.Guid, displayField = false };
                guid.fieldValue = schGuid;
                bparams.Add(guid);
                bsch.LoadRows("guidfield = ?", bparams);
                if (bsch.TableRows.Count > 0)
                {
                    bsch.schDate = schDate;
                    bsch.schFrom = schFrom;
                    bsch.schTo = schTo;
                    bsch.tutGuid = new Guid(tutGuid);
                    bsch.stuGuid1 = new Guid(stuGuid1);
                    if (Utils.IsGuid(stuGuid2))
                        bsch.stuGuid2 = new Guid(stuGuid2);
                    else
                        bsch.stuGuid2 = null;

                    if (Utils.IsGuid(stuGuid3))
                        bsch.stuGuid3 = new Guid(stuGuid3);
                    else
                        bsch.stuGuid3 = null;

                    if (Utils.IsGuid(stuGuid4))
                        bsch.stuGuid4 = new Guid(stuGuid4);
                    else
                        bsch.stuGuid4 = null;

                    if (Utils.IsGuid(stuGuid5))
                        bsch.stuGuid5 = new Guid(stuGuid5);
                    else
                        bsch.stuGuid5 = null;

                    if(! string.IsNullOrEmpty(isdelete))
                        bsch.isDeleted = isdelete;
                }
            }
            else
            {
                /* Add New */
                if (!(Utils.User.UserRoleByName("5.Schedules").allowAdd))
                {
                    Response.Write("{result:false,Message:'You do not have rights to add.'}");
                    return;
                }
                bsch.guidfield = Guid.NewGuid();
                bsch.schDate = schDate;
                bsch.schFrom = schFrom;
                bsch.schTo = schTo;
                bsch.tutGuid = new Guid(tutGuid);
                bsch.stuGuid1 = new Guid(stuGuid1);
                if (Utils.IsGuid(stuGuid2))
                    bsch.stuGuid2 = new Guid(stuGuid2);
                if (Utils.IsGuid(stuGuid3))
                    bsch.stuGuid3 = new Guid(stuGuid3);
                if (Utils.IsGuid(stuGuid4))
                    bsch.stuGuid4 = new Guid(stuGuid4);
                if (Utils.IsGuid(stuGuid5))
                    bsch.stuGuid5 = new Guid(stuGuid5);
                bsch.isDeleted = isdelete;
                bsch.attended1 = attend1;
                bsch.attended2 = attend2;
                bsch.attended3 = attend3;
                bsch.attended4 = attend4;
                bsch.attended5 = attend5;
            }

            if (bsch.CurrentRow.Save())
            {
                Response.Write("{result:true,guid:'" + bsch.CurrentRow.Fields["guidfield"].fieldValue + "'}");
            }
            else
            {
                Response.Write("{result:false,Message:'" + Utils.EnquoteJS( bsch.CurrentRow.lastError )+ "'}");
            }
        }
    }
}
